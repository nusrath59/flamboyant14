function thankYou(event) {
  event.preventDefault();
  alert("Thank you for registering! See you at the Alumni Meet.");
}
